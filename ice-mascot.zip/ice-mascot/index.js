/** Host half of the ice-mascot bundle; the Client module owns the rendering. */
export function apply() {}
