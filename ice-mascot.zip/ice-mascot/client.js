window.__ModuleLoader__.load({
  id: '@local/ice-mascot',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    // ---------- shared settings store (localStorage + subscribe) ----------
    const KEY = 'ice-mascot.settings.v1';
    const DEFAULTS = { body: '#8cc9f7', top: '#e3f6ff', face: '#2b4a63', sparkle: '#bfe8ff', x: null, y: null };
    let listeners = [];
    function read() {
      try {
        const raw = localStorage.getItem(KEY);
        if (raw) return Object.assign({}, DEFAULTS, JSON.parse(raw));
      } catch (e) {}
      return Object.assign({}, DEFAULTS);
    }
    let state = read();
    function getSettings() { return state; }
    function setSettings(patch) {
      state = Object.assign({}, state, patch);
      try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
      listeners.slice().forEach(function (fn) { fn(state); });
    }
    function subscribe(fn) {
      listeners.push(fn);
      return function () { listeners = listeners.filter(function (x) { return x !== fn; }); };
    }
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', function (e) {
        if (e.key === KEY) { state = read(); listeners.slice().forEach(function (fn) { fn(state); }); }
      });
    }

    // ---------- color utils ----------
    function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }
    function hexToRgb(hex) {
      let s = String(hex).replace('#', '');
      if (s.length === 3) s = s.split('').map(function (c) { return c + c; }).join('');
      const n = parseInt(s, 16);
      return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    }
    function rgbToHex(r, g, b) {
      const c = function (v) { return clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0'); };
      return '#' + c(r) + c(g) + c(b);
    }
    function rgbToHsl(r, g, b) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b);
      let hh = 0, s = 0; const l = (max + min) / 2;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r: hh = (g - b) / d + (g < b ? 6 : 0); break;
          case g: hh = (b - r) / d + 2; break;
          default: hh = (r - g) / d + 4;
        }
        hh /= 6;
      }
      return { h: hh * 360, s: s * 100, l: l * 100 };
    }
    function hslToRgb(hh, s, l) {
      hh /= 360; s /= 100; l /= 100;
      let r, g, b;
      if (s === 0) { r = g = b = l; }
      else {
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        const f = function (t) {
          if (t < 0) t += 1; if (t > 1) t -= 1;
          if (t < 1 / 6) return p + (q - p) * 6 * t;
          if (t < 1 / 2) return q;
          if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
          return p;
        };
        r = f(hh + 1 / 3); g = f(hh); b = f(hh - 1 / 3);
      }
      return { r: r * 255, g: g * 255, b: b * 255 };
    }
    function adjustLightness(hex, delta) {
      const rgb = hexToRgb(hex);
      const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
      const l = clamp(hsl.l + delta, 0, 100);
      const c = hslToRgb(hsl.h, hsl.s, l);
      return rgbToHex(c.r, c.g, c.b);
    }
    function lighten(hex, amt) { return adjustLightness(hex, amt); }
    function darken(hex, amt) { return adjustLightness(hex, -amt); }

    // ---------- toy-duck quack via Web Audio ----------
    let audioCtx = null;
    function playQuack() {
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        if (!audioCtx) audioCtx = new AC();
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const now = audioCtx.currentTime;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        const filter = audioCtx.createBiquadFilter();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.07);
        osc.frequency.exponentialRampToValueAtTime(470, now + 0.14);
        filter.type = 'lowpass';
        filter.frequency.value = 1500;
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.12, now + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);
        osc.connect(filter); filter.connect(gain); gain.connect(audioCtx.destination);
        osc.start(now); osc.stop(now + 0.25);
      } catch (e) {}
    }

    // ---------- texts ----------
    const isZh = typeof navigator !== 'undefined' && /^zh/i.test(navigator.language || '');
    const T = isZh ? {
      title: '冰宝', body: '身体颜色', top: '顶部高光', face: '五官颜色', sparkle: '星光颜色',
      presets: '配色方案', reset: '恢复默认', hint: '拖拽移动冰宝，点按听它“嘎嘎”叫～',
    } : {
      title: 'Ice Mascot', body: 'Body', top: 'Top highlight', face: 'Face', sparkle: 'Sparkles',
      presets: 'Presets', reset: 'Reset', hint: 'Drag to move the mascot, click to hear it quack!',
    };

    // ---------- shared CSS ----------
    const CSS = `
      .ice-mascot-spark { animation: ice-twinkle 1.9s ease-in-out infinite; }
      .ice-mascot-bob { animation: ice-bob 2.8s ease-in-out infinite; }
      .ice-mascot-anim { animation: ice-jump .6s ease; }
      @keyframes ice-bob { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-3px); } }
      @keyframes ice-jump {
        0% { transform: translateY(0) rotate(0) scale(1); }
        25% { transform: translateY(-16px) rotate(-8deg) scale(1.12); }
        50% { transform: translateY(0) rotate(6deg) scale(1); }
        75% { transform: translateY(-7px) rotate(-4deg) scale(1.06); }
        100% { transform: translateY(0) rotate(0) scale(1); }
      }
      @keyframes ice-twinkle { 0%,100% { opacity: .15; } 50% { opacity: .95; } }
    `;

    // ---------- shared mascot graphic ----------
    let idSeq = 0;
    function sparkle(x, y, color) {
      return h('path', {
        d: `M ${x} ${y - 6} L ${x + 2} ${y - 2} L ${x + 6} ${y} L ${x + 2} ${y + 2} L ${x} ${y + 6} L ${x - 2} ${y + 2} L ${x - 6} ${y} L ${x - 2} ${y - 2} Z`,
        fill: color,
        className: 'ice-mascot-spark',
      });
    }
    function MascotGraphic(opts) {
      const s = opts.settings;
      const uid = 'im' + (idSeq++);
      const top = lighten(s.body, 0.5);
      const mid = s.body;
      const bottom = darken(s.body, 0.2);
      const topA = s.top || '#ffffff';
      const topB = adjustLightness(topA, -0.22);
      return h('svg', {
        viewBox: '0 0 96 96', width: opts.size || 46, height: opts.size || 46,
        'aria-hidden': true, className: opts.className || '',
      },
        h('defs', null,
          h('linearGradient', { id: uid + '-b', x1: '0', y1: '0', x2: '0', y2: '1' },
            h('stop', { offset: '0%', stopColor: top }),
            h('stop', { offset: '55%', stopColor: mid }),
            h('stop', { offset: '100%', stopColor: bottom }),
          ),
          h('linearGradient', { id: uid + '-t', x1: '0', y1: '0', x2: '0', y2: '1' },
            h('stop', { offset: '0%', stopColor: topA }),
            h('stop', { offset: '100%', stopColor: topB }),
          ),
        ),
        h('rect', { x: 12, y: 20, width: 72, height: 58, rx: 14, fill: 'url(#' + uid + '-b)' }),
        h('path', {
          d: 'M 12 40 C 12 30 20 22 33 22 L 63 22 C 76 22 84 30 84 40 Z',
          fill: 'url(#' + uid + '-t)', opacity: 0.5,
        }),
        h('ellipse', { cx: 32, cy: 36, rx: 10, ry: 6, fill: '#ffffff', opacity: 0.7, transform: 'rotate(-18 32 36)' }),
        h('path', {
          d: 'M 12 70 L 84 70 C 84 74 84 76 79 79 L 17 79 C 12 76 12 74 12 70 Z',
          fill: darken(s.body, 0.32), opacity: 0.35,
        }),
        h('circle', { cx: 36, cy: 52, r: 3.4, fill: s.face }),
        h('circle', { cx: 60, cy: 52, r: 3.4, fill: s.face }),
        h('circle', { cx: 37.2, cy: 50.8, r: 1.1, fill: '#ffffff' }),
        h('circle', { cx: 61.2, cy: 50.8, r: 1.1, fill: '#ffffff' }),
        h('path', {
          d: 'M 42 60 C 45 65 51 65 54 60',
          fill: 'none', stroke: s.face, strokeWidth: 2.4, strokeLinecap: 'round', strokeLinejoin: 'round',
        }),
        sparkle(20, 16, s.sparkle),
        sparkle(76, 20, s.sparkle),
        sparkle(82, 56, s.sparkle),
      );
    }

    // ---------- draggable floating pet ----------
    function IceMascot() {
      const [settings, setSettingsState] = React.useState(getSettings());
      const [jump, setJump] = React.useState(0);
      const [dragging, setDragging] = React.useState(false);
      React.useEffect(function () {
        return subscribe(function (s) { setSettingsState(s); });
      }, []);

      let x = settings.x;
      let y = settings.y;
      if (x == null || y == null) {
        const w = typeof window !== 'undefined' ? window.innerWidth : 1200;
        const hh = typeof window !== 'undefined' ? window.innerHeight : 800;
        x = w - 90; y = hh - 150;
      }

      const startRef = React.useRef(null);
      function onPointerDown(e) {
        startRef.current = { clientX: e.clientX, clientY: e.clientY, x0: x, y0: y, x: x, y: y, moved: false };
        setDragging(true);
        try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) {}
      }
      function onPointerMove(e) {
        const r = startRef.current;
        if (!r) return;
        const dx = e.clientX - r.clientX;
        const dy = e.clientY - r.clientY;
        if (!r.moved && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) r.moved = true;
        r.x = r.x0 + dx; r.y = r.y0 + dy;
        setSettingsState(Object.assign({}, settings, { x: r.x, y: r.y }));
      }
      function onPointerUp() {
        const r = startRef.current;
        startRef.current = null;
        setDragging(false);
        if (r && !r.moved) { playQuack(); setJump(function (k) { return k + 1; }); }
        else if (r) { setSettings({ x: r.x, y: r.y }); }
      }

      return h('div', {
        className: 'ice-mascot-pet' + (dragging ? ' is-dragging' : ''),
        style: {
          position: 'fixed', left: x, top: y, pointerEvents: 'auto', touchAction: 'none',
          zIndex: 9999, cursor: dragging ? 'grabbing' : 'grab', userSelect: 'none',
        },
        onPointerDown: onPointerDown, onPointerMove: onPointerMove,
        onPointerUp: onPointerUp, onPointerCancel: onPointerUp,
      },
        h('style', null, CSS),
        h('div', { key: jump, className: jump ? 'ice-mascot-anim' : '' },
          MascotGraphic({ settings: settings, size: 52, className: 'ice-mascot-bob' }),
        ),
      );
    }

    // ---------- settings page ----------
    function IceMascotSettings(props) {
      const [settings, setSettingsState] = React.useState(getSettings());
      React.useEffect(function () {
        return subscribe(function (s) { setSettingsState(s); });
      }, []);

      const presets = [
        { name: T.title === '冰宝' ? '冰蓝' : 'Ice Blue', body: '#8cc9f7', top: '#e3f6ff', face: '#2b4a63', sparkle: '#bfe8ff' },
        { name: T.title === '冰宝' ? '小黄鸭' : 'Rubber Duck', body: '#ffd54a', top: '#fff2c2', face: '#7a5b1e', sparkle: '#ffe89a' },
        { name: T.title === '冰宝' ? '蜜桃粉' : 'Peach', body: '#ff9eac', top: '#ffe0e6', face: '#7a3f4c', sparkle: '#ffd0d8' },
        { name: T.title === '冰宝' ? '抹茶绿' : 'Matcha', body: '#a7d7a0', top: '#e6f5e3', face: '#3b6b37', sparkle: '#d2f0cc' },
        { name: T.title === '冰宝' ? '葡萄紫' : 'Grape', body: '#c9a6f2', top: '#efe2ff', face: '#4b2d6e', sparkle: '#e6d5ff' },
      ];

      function Field(label, value, onChange) {
        return h('label', { style: { display: 'flex', alignItems: 'center', gap: 10, margin: '8px 0' } },
          h('span', { style: { flex: 1, color: 'var(--dsw-alias-label-secondary)', fontSize: 13 } }, label),
          h('input', {
            type: 'color', value: value,
            onChange: function (e) { onChange(e.target.value); },
            style: { width: 40, height: 28, padding: 0, border: 'none', background: 'transparent', cursor: 'pointer' },
          }),
        );
      }

      function patch(p) { setSettings(p); }

      const rows = [
        Field(T.body, settings.body, function (v) { patch({ body: v }); }),
        Field(T.top, settings.top, function (v) { patch({ top: v }); }),
        Field(T.face, settings.face, function (v) { patch({ face: v }); }),
        Field(T.sparkle, settings.sparkle, function (v) { patch({ sparkle: v }); }),
      ];

      return h('div', { style: { padding: '2px 4px' } },
        h('style', null, CSS),
        h('div', { style: { display: 'flex', gap: 16, alignItems: 'flex-start' } },
          h('div', { style: { flex: '0 0 auto' } }, MascotGraphic({ settings: settings, size: 72 })),
          h('div', { style: { flex: 1, minWidth: 0 } },
            h('p', { style: { color: 'var(--dsw-alias-label-tertiary)', fontSize: 12, margin: '0 0 8px' } }, T.hint),
            rows,
          ),
        ),
        h('div', { style: { marginTop: 16 } },
          h('div', { style: { color: 'var(--dsw-alias-label-secondary)', fontSize: 13, marginBottom: 8 } }, T.presets),
          h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 8 } },
            presets.map(function (p) {
              return h('button', {
                key: p.name,
                onClick: function () { patch({ body: p.body, top: p.top, face: p.face, sparkle: p.sparkle }); },
                style: {
                  display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 10px', fontSize: 12,
                  border: '1px solid var(--dsw-alias-border-l1)', borderRadius: 8,
                  background: 'var(--dsw-alias-bg-layer-1)', color: 'var(--dsw-alias-label-primary)', cursor: 'pointer',
                },
              },
                h('span', { style: { width: 14, height: 14, borderRadius: '50%', background: p.body, display: 'inline-block' } }),
                p.name,
              );
            }),
          ),
        ),
        h('button', {
          onClick: function () { setSettings({ body: DEFAULTS.body, top: DEFAULTS.top, face: DEFAULTS.face, sparkle: DEFAULTS.sparkle }); },
          style: {
            marginTop: 16, padding: '6px 12px', fontSize: 13,
            border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 8,
            background: 'var(--dsw-alias-bg-layer-1)', color: 'var(--dsw-alias-label-primary)', cursor: 'pointer',
          },
        }, T.reset),
      );
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        ctx.slots.inject('shell.overlay', function () {
          return ctx.slots.register({ name: 'shell.overlay', id: 'ice-mascot', order: 5 }, IceMascot);
        });
        ctx.slots.inject('settings.section', function () {
          return ctx.slots.register({ name: 'settings.section', id: 'ice-mascot', order: 30, label: function () { return T.title; } }, IceMascotSettings);
        });
      },
    };
  },
});
